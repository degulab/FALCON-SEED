$Id: README.txt 23306 2002-07-09 15:53:56Z cxh $
ptolemy/plot/servlet/README.txt

This directory contains sample code to use Ptplot as a servlet.

The code was written by Alberto Gobbi, and has _not_ been tested
by the Ptplot pteam at UC Berkeley.

