$Id: README.txt 35717 2004-12-29 03:56:59Z cxh $
See package.html
